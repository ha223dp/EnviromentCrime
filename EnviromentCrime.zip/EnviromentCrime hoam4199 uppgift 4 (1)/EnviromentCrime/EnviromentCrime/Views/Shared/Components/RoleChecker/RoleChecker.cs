﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace EnviromentCrime.Views.Shared.Components.RoleChecker
{
	public class RoleChecker : PageModel
	{
		public void onGet()
		{

		}
	}
}
