﻿namespace EnviromentCrime.Models
{
	public class Sample
	{
		public int ErrandId { get; set; }

		public String SampleName { get; set; }

		public int SampleId { get; set; }
	}
}
