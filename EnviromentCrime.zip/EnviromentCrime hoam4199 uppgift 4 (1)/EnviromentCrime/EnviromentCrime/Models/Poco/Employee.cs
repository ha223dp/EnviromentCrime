﻿namespace EnviromentCrime.Models
{
    public class Employee
    {
        public String EmployeeId { get; set; }

        public String EmployeName { get; set; }

        public String RoleTitle { get; set; }

        public String DepartmentId { get; set; }
    }
}
