﻿namespace EnviromentCrime.Models
{
	public class Picture
	{
		public int PictureId { get; set; }

		public String PictureName { get; set; }

		public int ErrandId { get; set; }
	}
}
